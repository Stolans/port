package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private void Login(ActionEvent event) throws Exception {
        conn = mysqlconnect.ConnectDb();
        String sql = "Select * from users where username = ? and password = ? and type = ? ";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, txt_username.getText());
            pst.setString(2, txt_password.getText());
            pst.setString(3, String.valueOf(type.getSelectionModel().getSelectedItem()));

            rs = pst.executeQuery();

            if(rs.next()){
                JOptionPane.showMessageDialog(null, "Пароль и логин верны");

                    btn_login.getScene().getWindow().hide();

                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("Adminka.fxml"));

                    try {
                        loader.load();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Parent root = loader.getRoot();
                    Stage stage = new Stage();
                    stage.setScene(new Scene(root));
                    stage.showAndWait();

            }else
                JOptionPane.showMessageDialog(null, "Неверный логин или пароль, а может вообще тип");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void add_users(ActionEvent event) {
        conn = mysqlconnect.ConnectDb();
        String sql = "insert into users (username,password,type,email) values (?,?,?,?)";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, txt_username_up.getText());
            pst.setString(2, txt_password_up.getText());
            pst.setString(3, type_up.getValue().toString());
            pst.setString(4, email_up.getText());
            pst.execute();

            JOptionPane.showMessageDialog(null, "Saved");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }


    @FXML
    private AnchorPane pane_login;

    @FXML
    private AnchorPane pane_onas;

    @FXML
    private TextField txt_username;

    @FXML
    private PasswordField txt_password;

    @FXML
    private ComboBox type;

    @FXML
    private Button btn_login;

    @FXML
    private AnchorPane pane_signup;

    @FXML
    private TextField txt_username_up;

    @FXML
    private TextField txt_password_up;

    @FXML
    private TextField email_up;

    @FXML
    private Button ExitButton;

    @FXML
    private ComboBox type_up;


    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    public void Exit(){
        System.exit(1);
    }

    public void OnaspaneShow() {

        pane_onas.setVisible(true);
        pane_signup.setVisible(false);
        pane_login.setVisible(false);
    }



    public void LoginpaneShow() {

        pane_login.setVisible(true);
        pane_signup.setVisible(false);
        pane_onas.setVisible(false);
    }

    public void SignuppaneShow() {

        pane_login.setVisible(false);
        pane_signup.setVisible(true);
        pane_onas.setVisible(false);
    }

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {
        assert ExitButton != null : "fx:id=\"ExitButton\" was not injected: check your FXML file 'hello-view.fxml'.";
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        type_up.getItems().addAll("Admin", "Client", "Manager");
        type.getItems().addAll("Admin", "Client", "Manager");
    }
}
