package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class mysqlconnect {

    Connection conn = null;
    public static Connection ConnectDb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return (Connection) DriverManager.getConnection("jdbc:mysql://192.168.1.103/isp7", "isp7", "isp7");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }

    }

}

