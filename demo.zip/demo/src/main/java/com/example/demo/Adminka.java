package com.example.demo;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import static com.example.demo.Connector.getDataMagazin;


public class Adminka implements Initializable{

    @FXML
    private TableView<Magazin> table_Magazin;

    @FXML
    private TableColumn<Magazin, Integer> KodColumn;

    @FXML
    private TableColumn<Magazin, String> naimenovaniyeColumn;

    @FXML
    private TableColumn<Magazin, String> proizvoditelColumn;

    @FXML
    private TableColumn<Magazin, String> cenaColumn;

    @FXML
    private Button Back;


    @FXML
    private TextField txt_naimenovaniye;

    @FXML
    private TextField txt_proizvoditel;

    @FXML
    private TextField txt_cena;

    @FXML
    private TextField txt_kod;

    @FXML
    private TextField filterField;

    ObservableList<Magazin> listM;
    ObservableList<Magazin> dataList;


    int index = -1;

    Connection conn =null;
    ResultSet rs = null;
    PreparedStatement pst = null;


    public void Add_Magazin (){
        conn = Connector.ConnectDb();
        String sql = "insert into Magazin (Kod, Naimenovaniye, Proizvoditel, Cena)values(?,?,?,? )";
        try {
            assert conn != null;
            pst = conn.prepareStatement(sql);
            pst.setString(1, txt_kod.getText());
            pst.setString(2, txt_naimenovaniye.getText());
            pst.setString(3, txt_proizvoditel.getText());
            pst.setString(4, txt_cena.getText());
            pst.execute();

            JOptionPane.showMessageDialog(null, "Добавлено");
            UpdateTable();
            search_magazi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @FXML
    public void Back() {
        Back.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("hello-view.fxml"));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void getSelected (MouseEvent event){
        index = table_Magazin.getSelectionModel().getSelectedIndex();
        if (index <= -1){

            return;
        }
        txt_kod.setText(KodColumn.getCellData(index).toString());
        txt_naimenovaniye.setText(naimenovaniyeColumn.getCellData(index).toString());
        txt_proizvoditel.setText(proizvoditelColumn.getCellData(index).toString());
        txt_cena.setText(cenaColumn.getCellData(index).toString());

    }

    public void Edit (){
        try {
            conn = Connector.ConnectDb();
            String value1 = txt_kod.getText();
            String value2 = txt_naimenovaniye.getText();
            String value3 = txt_proizvoditel.getText();
            String value4 = txt_cena.getText();
            String sql = "update magazin set Kod= '"+value1+"',Naimenovaniye= '"+value2+"',Proizvoditel= '"+
                    value3+"',Cena= '"+value4+"' where Kod='"+value1+"' ";
            pst= conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Обновлено");
            UpdateTable();
            search_magazi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }


    public void Delete(){
        conn = Connector.ConnectDb();
        String sql = "delete from Magazin where Kod = ?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, txt_kod.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Delete");
            UpdateTable();
            search_magazi();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void UpdateTable(){
        KodColumn.setCellValueFactory(new PropertyValueFactory<Magazin,Integer>("Kod"));
        naimenovaniyeColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Naimenovaniye"));
        proizvoditelColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Proizvoditel"));
        cenaColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Cena"));

        listM = getDataMagazin();
        table_Magazin.setItems(listM);
    }

    @FXML
    void search_magazi() {
        KodColumn.setCellValueFactory(new PropertyValueFactory<Magazin,Integer>("Kod"));
        naimenovaniyeColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Naimenovaniye"));
        proizvoditelColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Proizvoditel"));
        cenaColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Cena"));

        dataList = getDataMagazin();
        table_Magazin.setItems(dataList);
        FilteredList<Magazin> filteredData = new FilteredList<>(dataList, b -> true);
        filterField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(person -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                if (person.getNaimenovaniye().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
                    return true;
                } else if (person.getProizvoditel().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                }else if (person.getCena().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                    return true;
                }

                else
                    return false;
            });
        });
        SortedList<Magazin> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(table_Magazin.comparatorProperty());
        table_Magazin.setItems(sortedData);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        UpdateTable();
        search_magazi();

    }
}