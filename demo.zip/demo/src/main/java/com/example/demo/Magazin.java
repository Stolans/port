package com.example.demo;

public class Magazin {
    int Kod ;
    String Naimenovaniye, Proizvoditel, Cena;

    public void setKod(int Kod) {
        this.Kod = Kod;
    }

    public void setNaimenovaniye(String Naimenovaniye) {
        this.Naimenovaniye = Naimenovaniye;
    }

    public void setProizvoditel(String Proizvoditel) {
        this.Proizvoditel = Proizvoditel;
    }

    public void setCena(String Cena) {
        this.Cena = Cena;
    }


    public int getKod() {
        return Kod;
    }

    public String getNaimenovaniye() {
        return Naimenovaniye;
    }

    public String getProizvoditel() {
        return Proizvoditel;
    }

    public String getCena() {
        return Cena;
    }


    public Magazin(int Kod, String Naimenovaniye, String Proizvoditel, String Cena) {
        this.Kod = Kod;
        this.Naimenovaniye = Naimenovaniye;
        this.Proizvoditel = Proizvoditel;
        this.Cena = Cena;
    }
}

