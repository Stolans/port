package com.example.demo;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import static com.example.demo.Connector.getDataMagazin;


public class Tabliza implements Initializable{

    @FXML
    private TableView<Magazin> table_Magazin;

    @FXML
    private TableColumn<Magazin, Integer> KodColumn;

    @FXML
    private TableColumn<Magazin, String> naimenovaniyeColumn;

    @FXML
    private TableColumn<Magazin, String> proizvoditelColumn;

    @FXML
    private TableColumn<Magazin, String> cenaColumn;

    @FXML
    private Button Back;

    ObservableList<Magazin> listM;
    ObservableList<Magazin> dataList;



    int index = -1;

    Connection conn =null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    @FXML
    public void Back() {
        Back.getScene().getWindow().hide();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("hello-view.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.showAndWait();
    }



    public void UpdateTable(){
        KodColumn.setCellValueFactory(new PropertyValueFactory<Magazin,Integer>("Kod"));
        naimenovaniyeColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Naimenovaniye"));
        proizvoditelColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Proizvoditel"));
        cenaColumn.setCellValueFactory(new PropertyValueFactory<Magazin,String>("Cena"));

        listM = getDataMagazin();
        table_Magazin.setItems(listM);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        UpdateTable();
    }
}