package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import javax.swing.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Connector {
    Connection conn = null;
    public static Connection ConnectDb() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return (Connection) DriverManager.getConnection("jdbc:mysql://192.168.1.103/isp7", "isp7", "isp7");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }

    }

    public static ObservableList<Magazin> getDataMagazin() {
        Connection conn = ConnectDb();
        ObservableList<Magazin> list = FXCollections.observableArrayList();
        try {
            assert conn != null;
            PreparedStatement ps = conn.prepareStatement("select * from Magazin");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Magazin(Integer.parseInt(rs.getString("Kod")), rs.getString("Naimenovaniye"), rs.getString("Proizvoditel"), rs.getString("Cena")));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

}


    
    